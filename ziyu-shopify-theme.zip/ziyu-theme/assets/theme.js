/* ============================================
   ZIYU DEVELOPMENT — THEME JS
   ============================================ */

(function () {
  'use strict';

  // ── MOBILE NAV ──────────────────────────────
  const toggle = document.querySelector('.nav-toggle');
  const mobileNav = document.getElementById('nav-mobile');

  if (toggle && mobileNav) {
    toggle.addEventListener('click', () => {
      const isOpen = mobileNav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', isOpen);
    });
  }

  // ── HEADER SCROLL SHADOW ────────────────────
  const header = document.getElementById('site-header');
  if (header) {
    const onScroll = () => {
      header.classList.toggle('scrolled', window.scrollY > 10);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // ── HERO CAROUSEL ───────────────────────────
  const carousel = document.getElementById('hero-carousel');
  if (carousel) {
    const slides = carousel.querySelectorAll('.hero-slide');
    const dots   = carousel.querySelectorAll('.dot');
    const prev   = carousel.querySelector('.carousel-prev');
    const next   = carousel.querySelector('.carousel-next');

    if (slides.length > 1) {
      let current = 0;
      let timer;

      function goTo(index) {
        slides[current].classList.remove('active');
        dots[current]?.classList.remove('active');
        current = (index + slides.length) % slides.length;
        slides[current].classList.add('active');
        dots[current]?.classList.add('active');
      }

      function startAuto() {
        clearInterval(timer);
        timer = setInterval(() => goTo(current + 1), 5000);
      }

      prev?.addEventListener('click', () => { goTo(current - 1); startAuto(); });
      next?.addEventListener('click', () => { goTo(current + 1); startAuto(); });

      dots.forEach((dot, i) => {
        dot.addEventListener('click', () => { goTo(i); startAuto(); });
      });

      // Touch swipe
      let touchStartX = 0;
      carousel.addEventListener('touchstart', e => {
        touchStartX = e.touches[0].clientX;
      }, { passive: true });
      carousel.addEventListener('touchend', e => {
        const diff = touchStartX - e.changedTouches[0].clientX;
        if (Math.abs(diff) > 50) {
          goTo(diff > 0 ? current + 1 : current - 1);
          startAuto();
        }
      }, { passive: true });

      startAuto();
    }
  }

  // ── BLOG FILTERS ────────────────────────────
  const filterBtns = document.querySelectorAll('.filter-btn');
  if (filterBtns.length) {
    const blogCards = document.querySelectorAll('.blog-card[data-tags]');

    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const tag = btn.dataset.tag;
        blogCards.forEach(card => {
          const tags = card.dataset.tags || '';
          if (tag === 'all' || tags.includes(tag)) {
            card.style.display = '';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  }

  // ── SCROLL REVEAL ───────────────────────────
  if ('IntersectionObserver' in window) {
    const revealEls = document.querySelectorAll(
      '.app-card, .blog-card, .product-card, .goal-item, .team-card'
    );

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          entry.target.style.animationDelay = `${i * 0.05}s`;
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    revealEls.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(16px)';
      el.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      observer.observe(el);
    });

    // trigger
    document.querySelectorAll('.revealed').forEach(el => {
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
    });
  }

})();

// Scroll reveal trigger (separate to fire after observer setup)
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.querySelectorAll('.app-card, .blog-card, .product-card, .goal-item, .team-card').forEach(el => {
      if (el.getBoundingClientRect().top < window.innerHeight) {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }
    });
  }, 100);
});
